﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SayedR11EmployeeWage
{
    public partial class Form1 : Form
    {
        private object txtWages;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            DialogResult ButtonSelected;
            ButtonSelected = MessageBox.Show(
                "Do you really want to quit?", "Exiting...",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
            if (ButtonSelected == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtHoursWorked.Clear();
            txtEmployeeName.Clear();
            txtHourlyRate.Clear();
            lstOutput.Items.Clear();
            txtEmployeeName.Focus();
        }
        

        private void btnCalculateTotalEarn_Click(object sender, EventArgs e)
        {
            string EmployeeName;
            double HoursWorked;
            double HourlyRate;
            double WeeklyWages;
            bool RateValid, WorkedValid;
            
            //Input 
            //Parse converts string to double
            //HourlyRate = double.Parse(txtHourlyRate.Text);
            //HoursWorked = double.Parse(txtHoursWorked.Text);
            //convert parse to tryparse
            RateValid = double.TryParse(txtHourlyRate.Text, out HourlyRate);
            WorkedValid = double.TryParse(txtHoursWorked.Text, out HoursWorked);
            if (RateValid & WorkedValid)
            {
                EmployeeName = txtEmployeeName.Text;


                //Processing


                WeeklyWages = HoursWorked * HourlyRate;


                //Output
                lstOutput.Items.Add("Employee Name is " + EmployeeName);
                lstOutput.Items.Add("Hourly Rate is " + HourlyRate.ToString("C2"));
                lstOutput.Items.Add("Hours Worked is " + HoursWorked.ToString("N2"));
                lstOutput.Items.Add("Weekly Wages are " + WeeklyWages.ToString("C2"));

            }
            else
            {
                if (!RateValid)
                {
                    lstOutput.Items.Add("Please enter a numeric value for hourly rate");
                }
                if (!WorkedValid)
                {
                    lstOutput.Items.Add("Please enter a numeric value for hours worked");
                }
            }

            //This changes the focus to the clear button




            btnClear.Focus();
            
        }

        private void txtEmployeeName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmployeeName_Enter(object sender, EventArgs e)
        {
            txtEmployeeName.BackColor = Color.Bisque;
        }

        private void txtEmployeeName_Leave(object sender, EventArgs e)
        {
            txtEmployeeName.BackColor = SystemColors.Window;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtHoursWorked_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
